const titulo = 
document.getElementById("titulo");

const primeiroItem = 
document.querySelector(".item");

const cards = 
document.querySelectorAll(".card"); 

const botao2 = 
document.querySelector("#btn-ver-carrinho");

const botao1 = 
document.querySelector("btn-carrinho");

console.log("Titulo:", titulo);
console.log("Primeiro item:", primeiroItem);
console.log("Todos os cards:", cards);

let carrinho = [];
let itemSelecionado = null;

cards.forEach(function(card) {
    card.addEventListener("click", function() {
        cards.forEach(c => c.classList.remove("ativo"));
        card.classList.add("ativo");
        itemSelecionado = card;
    });
});

const nome =
itemSelecionado.querySelector("h3").TextContent;

const preco = 
itemSelecionado.querySelector("p").TextContent;

carrinho.push({nome: nome, preco: preco});

const preco = Number(itemSelecionado.dataset.preco);








